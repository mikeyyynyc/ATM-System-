#Define the ATM Class
class Atm:
    def __init__(self): 
        self.__pin = None   #attribute
        self.__balance = 0  #attribute
        self.__menu()       #defining menu within the ATM class

    #Adding the Menu Method
    def __menu(self):
        while True: #allows the code to be continously repeated no matter what.
            print("\nATM Menu:") #menu title
            print("1. Generate PIN")   #choice1 
            print("2. Change PIN")     #choice2
            print("3. Check Balance")  #choice3
            print("4. Deposit Money")  #choice4
            print("5. Withdraw Money") #choice5
            print("6. Send Money")     #choice6
            print("7. Exit")           #choice7
            
            choice = input("Select an option (1-7): ")

            if choice == '1':
                self.__generate_pin() 
            elif choice == '2':
                self.__change_pin()
            elif choice == '3':
                self.__check_balance()
            elif choice == '4':
                self.__deposit()
            elif choice == '5':
                self.__withdraw()
            elif choice == '6':
                self.__sendmoney()
            elif choice == '7':
                print("Exiting...")
                break 
            else:
                print("Invalid option. Please try again.")

    #Adding Pin Handling Methods
    def __get_pin(self):
        while True:     #allows the code to be continously repeated no matter what.
            pin = input("Enter your 4-digit PIN: ")
            if len(pin) == 4 and pin.isdigit(): 
                return pin  #pin will only be returned if it is 4 digits.
            else:
                print("Invalid PIN. Please enter a 4-digit number.") 
                #^^if not following the conditions, the atm will print out this.

    def __verify_pin(self):
        pin = self.__get_pin()
        if pin == self.__pin:
            return True  #this will return when the original pin is typed to verify.
        else:
            print("Incorrect PIN.")
            return False  #if it is not the original pin generated.

#Implementing Pin Generation
    def __generate_pin(self):
        if self.__pin is not None:
            print("PIN already set. Returning to menu.")
            return #only if a pin has already been made.
        while True:     #allows the code to be continously repeated no matter what.
            new_pin = self.__get_pin()
            confirm_pin = input("Confirm PIN: ")
            if new_pin == confirm_pin:
                self.__pin = new_pin     #the pin typed will be made as the newest pin.
                print("PIN generated successfully.")
                break     #ends when pin has been generated successfully.
            else:
                print("PINs do not match. Please try again.")

#Implementing Pin Change
    def __change_pin(self):
        if self.__pin is None: 
            print("No PIN set yet. Please generate a PIN first.")
            return     #only if a pin hasn't been made.
        if self.__verify_pin():
            while True:     #allows the code to be continously repeated no matter what.
                new_pin = self.__get_pin()
                confirm_pin = input("Confirm new PIN: ")
                if new_pin == confirm_pin:
                    self.__pin = new_pin
                    print("PIN changed successfully.")
                    break     #ends when pin has been changed successfully.
                else:
                    print("PINs do not match. Please try again.")   

# Implementing Balance Check
    def __check_balance(self):
        if self.__verify_pin():
            print("Your current balance is:", self.__balance) 
            #if pin created has been verified, balance will display.

#Implementing Withdrawl
    def __withdraw(self):
        if self.__verify_pin():
            while True: #allows the code to be continously repeated no matter what.
                amount = int(input("Enter amount to withdraw (multiples of 20): ")) 
                if amount % 20 == 0 and amount < self.__balance: 
                #allows only multiples of 20's and less than the balance to be withdrew.
                    self.__balance -= amount
                    print("Withdrawal successful. New balance:", self.__balance)
                    break      #ends when withdrawl is successful.
                else: 
                    print("Invalid amount. Please enter a "
                          "multiple of 20 and less than balance.") 
                    

#Implementing Deposit
    def __deposit(self):
        if self.__verify_pin():
            while True:     #allows the code to be continously repeated no matter what.
                amount = int(input("Enter amount to deposit (multiple of 20): "))
                if amount % 20 == 0 and amount > 0:
         #allows a deposit to happen when a multiple of 20 is inserted and is > than 0.
                    self.__balance += amount
                    print("Deposit successful. New balance:", self.__balance)
                    break     #ends when deposit is successful.
                else:
                    print("Invalid amount. Please enter a "
                           "multiple of 20 and greater than 0.")


#Sending Money
    def __sendmoney(self):
        if self.__verify_pin():
            while True:   #allows the code to be continously repeated.
                amount = int(input("Enter amount to send: "))
                if amount > 0 and amount < self.__balance:
                    self.__balance -= amount
                    name = str(input("Who do you want to send money?: "))
                    print(f"You have sent ${amount} to {name}! ")
                    break      #ends when deposit is successful.
                else:                
                    print("Invalid amount. Please enter a "
                                      "amount less than your balance.")
#Create ATM
if __name__ == "__main__": 
    system = Atm() 
    #allows the code to run.

